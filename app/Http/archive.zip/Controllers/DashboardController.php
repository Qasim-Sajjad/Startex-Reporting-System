<?php



namespace App\Http\Controllers;



use illuminate\Http\Request;

use App\Models\User;

use Auth;

use Illuminate\Support\Facades\Session;

use App\Models\Format;



use PhpOffice\PhpSpreadsheet\IOFactory;

use App\Models\hierarchynames;

use App\Models\Hierarchylevels;

use App\Models\hierarchies;

use App\Models\locations;

use Illuminate\Support\Facades\DB;

use App\Models\assignprojects;

use App\Models\waves;

use App\Models\assignshops;



class DashboardController extends Controller

{

    public function dashboard()

    {
        // dd(122);
        // echo "sia";
        // exit();
 $role = session::get('user_role');
    // Check the role from the session and return the appropriate dashboard view
if ($role == "Super Admin") {
  return view('superadmin.dashboard');
    } elseif ($role == "Client Admin") {
        return view('admin.dashboard');
    } else {
        // If role is not found or is not recognized, redirect to login with an error message
        return redirect('login')->with('error', 'Credential not available');
    }
    }

    public function getWaves($formatId)

    {
        // dd(1);
        // dd($formatId);
        // echo $formatId;

        $waves = DB::table('waves')->where('format_id', $formatId)->get();

        $wave = DB::table('waves')

            ->where('format_id', $formatId)

            ->orderBy('id', 'DESC')

            ->first();

        $ytdWaveId =  $wave->id;

        // if ($wave) {

        //     Session::put('YTD', $wave->id);

        // }

        return response()->json(['waves' => $waves, 'YTD' => $ytdWaveId]);
    }
}
