<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CommentAnalysisController extends Controller
{
    //
}
