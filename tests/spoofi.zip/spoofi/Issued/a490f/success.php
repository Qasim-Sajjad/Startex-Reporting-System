<!DOCTYPE html>
<html>
  <head>
  </head>
  <body>
    <p style="text-align: center;"><img src="https://i.ytimg.com/vi/hJbaOPJvgYw/maxresdefault.jpg"
        alt="x"
        title="x"
        style="width: 507px; height: 285px;"></p>
    <h4 class="defanged2-font defanged2-title-subtitle-title" style="  margin: 0px; padding: 0px; color: rgb(0, 0, 0); font-style: inherit; font-variant: inherit; font-weight: bold; font-stretch: inherit; font-size: 40px; line-height: 45px; font-family: Circular, &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; letter-spacing: -0.04em; text-align: center; border: none; text-decoration: none;">Your
      account has been upgraded.</h4>
    <p><br>
    </p>
    <p></p>
    <h4 class="defanged2-font defanged2-title-subtitle-title" style="margin: 0px; padding: 0px; color: black; font-style: inherit; font-variant: inherit; font-weight: bold; font-stretch: inherit; font-size: 40px; line-height: 45px; font-family: Circular,&quot;Helvetica Neue&quot;,Helvetica,Arial,sans-serif; letter-spacing: -0.04em; text-align: center; border: medium none; text-decoration: none;">
      <meta charset="utf-8">
    </h4>
    <p></p>
  </body>
</html>
