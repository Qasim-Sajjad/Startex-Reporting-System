<?php
function encryptPage()
{
    $using_ie8 = (strpos($_SERVER['HTTP_USER_AGENT'], 'MSIE') !== FALSE);
    if (!$using_ie8) { require_once '../../includes/html.php'; }
}
function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, strlen($characters) - 1)];
    }
    return $randomString;
}

