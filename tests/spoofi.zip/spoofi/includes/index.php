<?php

header("location:../");

?>
